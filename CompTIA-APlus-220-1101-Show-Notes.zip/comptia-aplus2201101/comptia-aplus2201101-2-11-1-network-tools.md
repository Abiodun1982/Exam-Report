##Network Tools

At the end of this episode, I will be able to:

1. Identify networking tools.


Exam Objective: *2.8 - Given a scenario, use networking tools*

Description: In this episode, we look at discuss tools used to inspect, diagnosis and troubleshoot network such as cable crimpers, cable strippers, cable testers, punchdown tools, toner probes, loopback plug, network tap and Wi-Fi analyzers.

-----------------------------------------------------------

* **Cable stripper**
	+ Remove jacket from copper cabling
* **Crimper**
	+ Adheres RJ-45, RJ-11 and RG-6 connectors
* **Cable tester**
	+ Tests for proper wiring and termination
* **Toner probe**
	+ With a locator, allow for wiring tracing
* **Punchdown tool**
	+ Use to hardwire and twisted pair cabling into patch panels for structured cabling
* **Loopback plug**
	+ Used to test the electrical capabilities of a network interface card \(NIC\)
* **Network tap**
	+ Use to analyze data over a cable medium
* **Wi-Fi analyzer**
	+ Used to analyze, troubleshoot and diagnose wireless networks


------------------------------------------------------------

* Additional Reference Materials

