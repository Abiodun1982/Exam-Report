##Dynamic Host Configuration Protocol


At the end of this episode, I will be able to:

1.  Identify key attributes of the DHCP protocol.

Exam Objective: *2.5 - Compare and contrast common network configuration concepts.*

Description: In this episode, we discuss the Dynamic Host Configuration Protocol commonly called DHCP. We will explore the DHCP leases, the DORA lease process, scopes and reservations.



-------------------------------------------

* Common cloud models
	+ Private cloud
	+ Public cloud
	+ Hybrid cloud
	+ Community cloud
* Cloud Services
	+ Software as a service \(SaaS\)
	+ Infrastructure as a service \(IaaS\)
	+ Platform as a service \(PaaS\)
* Cloud characteristics
	+ Shared resources
	+ Metered utilization
	+ Rapid elasticity
	+ High availability
	+ File synchronization
------------------------------------------------------------

* Additional Reference Materials
	+ Not applicable if blank
